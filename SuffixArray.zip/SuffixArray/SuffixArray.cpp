#include <algorithm>
#include "SuffixArray.h"

SuffixArray::SuffixArray(const char* s) {
    size = 0;
    while (s[size] != '\0') size++; // Calculate the size of the input string

    // Allocate memory for arrays
    str = new char[size];
    rank = new int[size];
    suf = new int[size];
    temp = new int[size];

    // Copy the input string to the array
    for (int i = 0; i < size; ++i) {
        str[i] = s[i];
    }
}

SuffixArray::~SuffixArray() {
    // Free allocated memory
    delete[] str;
    delete[] rank;
    delete[] suf;
    delete[] temp;
}
void SuffixArray ::  ConstructUsingPrefixDoubling(){
    for (int i = 0; i < size; ++i) {
        suf[i] = i;
        rank[i] = str[i]; // Use ASCII value as initial rank
    }

    for (int len = 1; len < size; len *= 2) {
        // Comparator lambda for sorting suffix indices
        auto compare = [&](int a, int b) -> bool {
            if (rank[a] != rank[b])
                return rank[a] < rank[b];
            int rankA = (a + len < size) ? rank[a + len] : -1;
            int rankB = (b + len < size) ? rank[b + len] : -1;
            return rankA < rankB;
        };

        // Sort suffix indices based on the current rank
        for (int i = 0; i < size; ++i) {
            for (int j = i + 1; j < size; ++j) {
                if (compare(suf[j], suf[i])) {
                    int temp = suf[i];
                    suf[i] = suf[j];
                    suf[j] = temp;
                }
            }
        }

        // Update temporary ranks
        temp[suf[0]] = 0;
        for (int i = 1; i < size; ++i) {
            temp[suf[i]] = temp[suf[i - 1]];
            if (compare(suf[i - 1], suf[i]))
                temp[suf[i]]++;
        }

        // Update ranks for the next iteration
        for (int i = 0; i < size; ++i) {
            rank[i] = temp[i];
        }

        // Optimization: if all ranks are unique, break early
        if (rank[suf[size - 1]] == size - 1)
            break;
    }
}
void SuffixArray :: Print(){
    for (int i=0 ; i< size; ++i){
        cout<<suf[i]<<" ";
    }
    cout<<"\n";
}