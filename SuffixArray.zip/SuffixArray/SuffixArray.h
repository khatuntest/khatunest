#include<iostream>
#include<deque>
using namespace std;

#ifndef SUFFIXARRAY_SUFFIXARRAY_H
#define SUFFIXARRAY_SUFFIXARRAY_H


class SuffixArray {
private:
    int size;
    char* str;
    int* rank;
    int* suf;
    int* temp;

public:
    SuffixArray(const char* s);
    ~SuffixArray(); // Destructor to free memory
    void ConstructUsingPrefixDoubling();
    void Print();
};


#endif //SUFFIXARRAY_SUFFIXARRAY_H
